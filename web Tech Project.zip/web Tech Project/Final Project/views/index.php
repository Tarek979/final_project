<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/indexCss.css">
    <script>
        function validLogin(form) {
            const username = form.Username.value.trim();
            const password = form.Password.value.trim();

            // Validate username
            if (username === '') {
                alert('Username cannot be empty.');
                return false; // Prevent form submission
            }

            // Validate password
            if (password === '') {
                alert('Password cannot be empty.');
                return false; // Prevent form submission
            }

            // If all validations pass
            return true; // Allow form submission
        }
    </script>
</head>

<body>
    <div class="container">
        <h1>Login</h1>
        <?php
        if (isset($_GET['login']) && $_GET['login'] === 'failed') {
            echo '<p class="error">Your username or password is incorrect!</p>';
        }
        if (isset($_GET['registration']) && $_GET['registration'] === 'successful') {
            echo '<p class="success">Registration successful</p>';
        }
        if (isset($_GET['delete']) && $_GET['delete'] === 'successful') {
            echo '<p class="success">Account deleted</p>';
        }
        ?>
        <form action="../controllers/loginAction.php" method="post" onsubmit="return validLogin(this)" novalidate>
            <div class="form-row">
                <label for="username">Username</label>
                <input type="text" name="Username" id="username"
                    value="<?php echo isset($_GET['username']) ? htmlspecialchars($_GET['username']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label for="password">Password</label>
                <input type="password" name="Password" id="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        <form action="registration.php" style="margin-top: 15px;">
            <button type="submit">Registration</button>
        </form>
    </div>
</body>

</html>