<?php
include "../models/functions.php";
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

// Check if the room number is provided
if (isset($_GET['room_num'])) {
    $room_num = $_GET['room_num'];

    // Book the room
    $result = bookRoom($room_num, $username);

    if ($result) {
        $message = "Room number " . htmlspecialchars($room_num) . " has been successfully booked!";
    } else {
        $message = "Failed to book room number " . htmlspecialchars($room_num) . ". Please try again.";
    }
} else {
    header("Location: customerDashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <link rel="stylesheet" href="css/dashboardCss.css">
</head>

<body>
    <header>
        <h1>Hotel Management App</h1>
    </header>
    <nav>
        <ul>
            <li><a href="customerDashboard.php">Home</a></li>
            <li><a href="searchRoom.php">Search rooms</a></li>
            <li><a href="../controllers/logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <main>
            <h2>Booking Status</h2>
            <p><?php echo $message; ?></p>
            <a href="customerDashboard.php">Back to Dashboard</a>
        </main>
    </div>
    <footer>
        <p>&copy; 2024 My Website</p>
    </footer>
</body>

</html>