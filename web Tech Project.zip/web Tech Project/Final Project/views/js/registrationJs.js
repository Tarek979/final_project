function validRegistration(pForm){
    const usernameStatus = document.getElementById('username-status').innerText;
    const username = pForm.Username.value.trim();
    const name = pForm.name.value.trim();
    const password = pForm.Password.value;
    const confirmPassword = pForm.ConfirmPassword.value;
    
    
    if (usernameStatus !== 'Username is available.') {
        alert('Please choose a valid username.');
        return false; 

    
    if (name === '') {
        alert('Name cannot be empty.');
        return false; 
    }

    
    if (password.length < 8) {
        alert('Password must be at least 8 characters long.');
        return false; 
    }

    
    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return false; 
    }

    
    return true; 
    }
}
