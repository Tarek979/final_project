function validLogin(form) {
    const username = form.Username.value.trim();
    const password = form.Password.value.trim();

    // Validate username
    if (username === '') {
        alert('Username cannot be empty.');
        return false; // Prevent form submission
    }

    // Validate password
    if (password === '') {
        alert('Password cannot be empty.');
        return false; // Prevent form submission
    }

    // If all validations pass
    return true; // Allow form submission
}
