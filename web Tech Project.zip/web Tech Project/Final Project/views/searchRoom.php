<?php
include "../models/functions.php";
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];

// Fetch the logged-in customer's details
$customer = getCustomer($username);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard</title>
    <link rel="stylesheet" href="css/dashboardCss.css">
    <style>
        .book-button {
            display: inline-block;
            padding: 10px 15px;
            margin-left: 10px;
            background-color: #007BFF;
            /* Bootstrap primary color */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .book-button:hover {
            background-color: #0056b3;
            /* Darker shade on hover */
        }
    </style>
</head>

<body>
    <header>
        <h1>Hotel Management App</h1>
    </header>
    <nav>
        <ul>
            <li><a href="customerDashboard.php">Home</a></li>
            <li><a href="searchRoom.php">Search rooms</a></li>
            <li><a href="../controllers/logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <main>
            <h2>Available Rooms</h2>
            <?php
            // Fetch available rooms (status not equal to 1)
            $availableRooms = getAvailableRooms();

            if ($availableRooms && mysqli_num_rows($availableRooms) > 0) {
                echo "<ul>";
                while ($room = mysqli_fetch_assoc($availableRooms)) {
                    echo "<li>Room Number: " . htmlspecialchars($room['room_num']) . " <a href='bookRoom.php?room_num=" . urlencode($room['room_num']) . "' class='book-button'>Book Now</a></li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No available rooms at the moment.</p>";
            }
            ?>
        </main>
    </div>
    <footer>
        <p>&copy; 2024 My Website</p>
    </footer>
</body>

</html>