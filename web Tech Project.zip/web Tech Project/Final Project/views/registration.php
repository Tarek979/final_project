<?php
require_once('common.php');
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <link rel="stylesheet" href="css/registrationCss.css">
    <script src="registrationJs.js"></script>
</head>

<body>
    <div class="container">
        <h1>Registration</h1>

        <?php
        if (isset($_GET['registration']) && $_GET['registration'] === 'failed') {
            echo '<p class="error">Registration failed. Please try again.</p>';
        }
        ?>

        <form action="../controllers/registrationAction.php" method="post" onsubmit="return validRegistration(this)"
            novalidate>
            <div class="form-row">
                <label for="username">Username</label>
                <input type="text" name="Username" id="username" placeholder="Enter your username" required>
                <span id="username-status" class="error-message"></span>
            </div>
            <div class="form-row">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" placeholder="Enter your name" required>
            </div>
            <div class="form-row">
                <label for="password">Password</label>
                <input type="password" name="Password" id="password" placeholder="Enter your password" required>
            </div>
            <div class="form-row">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" name="ConfirmPassword" id="confirm_password" placeholder="Confirm your password"
                    required>
            </div>
            <button type="submit">Register</button>
        </form>


    </div>
    <<script src="https://code.jquery.com/jquery-3.6.0.min.js">
        </script>
        <script>
            $(document).ready(function () {
                $('#username').on('blur', function () {
                    var username = $(this).val();
                    if (username) {
                        $.ajax({
                            url: '../controllers/validateEmail.php', // Path to the validation script
                            type: 'POST',
                            data: { username: username },
                            success: function (response) {
                                $('#username-status').text(response).css('color', response === 'Username is available.' ? 'green' : 'red');
                            },
                            error: function () {
                                $('#username-status').text('An error occurred. Please try again.').css('color', 'red');
                            }
                        });
                    } else {
                        $('#username-status').text('');
                    }
                });
            });
        </script>


</body>

</html>