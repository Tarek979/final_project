<?php
include "../models/functions.php";
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];

$user = getUser($username);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard</title>
    <link rel="stylesheet" href="css/dashboardCss.css">
</head>

<body>
    <header>
        <h1>Hotel Management App</h1>
    </header>
    <nav>
        <ul>
            <li><a href="managerDashboard.php">Home</a></li>
            <li><a href="showGuest.php">Show guests</a></li>
            <li><a href="../controllers/logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <main>
            <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>

            <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($user['contact_number']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address']); ?></p>
            <p><strong>Role:</strong> <?php echo htmlspecialchars($user['role']); ?></p>
        </main>
    </div>
    <footer>
        <p>&copy; 2024 My Website</p>
    </footer>
</body>

</html>