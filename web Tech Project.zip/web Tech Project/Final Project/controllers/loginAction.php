<?php
require_once('../views/common.php');
require_once("../models/functions.php");
$isValid = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = sanitize($_POST['Username']);
    $password = sanitize($_POST['Password']);


    $isValid = matchCredential($username, $password);

}


if (!$isValid) {
    header("Location: ../views/index.php?login=failed&username=$username");
} else {
    $user = getUser($username);
    if ($user['role'] === "manager") {
        $_SESSION['username'] = $username;
        header("Location: ../views/managerDashboard.php");
    } else {
        $_SESSION['username'] = $username;
        header("Location: ../views/customerDashboard.php");
    }

}

?>