<?php
require_once('common.php');

if (isset($_POST['username'])) {
    $username = $_POST['username'];

    // Prepare SQL to check if username exists
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        echo 'Username is already taken.';
    } else {
        echo 'Username is available.';
    }

    mysqli_stmt_close($stmt);
}
?>