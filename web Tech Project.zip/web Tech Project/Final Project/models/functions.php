<?php
session_start();
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
function insertToDatabase($username, $password, $name)
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    // Create a connection
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO userInfo (username, password, name) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("sss", $username, $password, $name);

    // Execute the query and check the result
    $success = $stmt->execute();

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    return $success;
}
function matchCredential($username, $password)
{
    $isValid = false;
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    } else {
        echo "Connected with the database";
    }

    //Query
    $query = "SELECT *FROM userInfo WHERE username = '$username' AND password = '$password';";
    //Execute the query and store result in the result variable
    $result = $conn->query("$query");

    $userInfo = $result->fetch_assoc();

    if ($result->num_rows === 1) {
        $_SESSION['userId'] = $userInfo['id'];
        $isValid = true;
    }

    return $isValid;
}
function getUser($username)
{
    $isValid = false;
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    }
    //Query
    $query = "SELECT *FROM userInfo WHERE username = '$username' ;";
    //Execute the query and store result in the result variable
    $result = $conn->query("$query");

    $userInfo = $result->fetch_assoc();
    return $userInfo;
}
function getAllCustomers()
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    }

    $sql = "SELECT name, username, contact_number, address FROM userInfo WHERE role = 'customer';";
    $result = $conn->query($sql);

    $customers = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
    }
    return $customers;
}

function getCustomer($username)
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    }

    $sql = "SELECT name, username, contact_number, address FROM userInfo WHERE username = '$username';";
    $result = $conn->query($sql);


    $userInfo = $result->fetch_assoc();
    return $userInfo;
}

function getAvailableRooms()
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    }

    $query = "SELECT room_num FROM rooms WHERE status != 1";
    $result = mysqli_query($conn, $query);

    return $result; // Returns the result set
}

function bookRoom($room_num, $username)
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "practiceApp";

    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
    if ($conn->connect_error) {
        die("Connection failed : " . $conn->connect_error);
    }

    // Update the room's status to booked (1)
    $query = "UPDATE rooms SET status = 1 WHERE room_num = ?";

    // Prepare statement to prevent SQL injection
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $room_num);

    // Execute the query
    if (mysqli_stmt_execute($stmt)) {
        // You may want to log the booking details or save it to another table for bookings
        return true; // Successfully booked
    } else {
        return false; // Failed to book
    }
}



